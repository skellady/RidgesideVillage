<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="indoor" tilewidth="16" tileheight="16" tilecount="2176" columns="32">
 <image source="../../../../SDV Modding/Map Editing 2/Maps/townInterior" width="512" height="1088"/>
</tileset>
